import 'package:evenzia/Authentication/login.dart';
import 'package:evenzia/profile/profile.dart';
import 'package:flutter/material.dart';

import 'Authentication/selectRoll.dart';
import 'Authentication/signUp.dart';

import 'Src/student/studentHome.dart';
import 'imagePic.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home:
       // StudentHome(),
        // ViewNotification(uri: 'student/notifications',),
      // AddAdvisorNotification(),
      // ImagePic()
      //      SignUp(typeUser: '3', Url: 'student/register',) ,
      //    SignUp(typeUser: '2', Url: 'department-rep/register',) ,
      //     SignUp(typeUser: '1', Url:'advisor/register',) ,
      //      SignUp(typeUser: '1', Url:'secretary/register',) ,
        // SignUp(typeUser: '1', Url: 'media/register',) ,

          // Profile(Url: '',)
       SelectRoll(),
      //    LoginPage(logUrl: 'student/login',),
    );
  }
}

//department 2
//Student 3
//media 1
