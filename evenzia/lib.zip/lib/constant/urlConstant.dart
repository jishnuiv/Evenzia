
import 'package:flutter/material.dart';
    const String UrlConst='https://evenzia.websitepreview.in/api/';
// const String UrlConst='http://192.168.29.91:8000/api/';
//   const String UrlConst='http://127.0.0.1:8000/api/';
const spacer= SizedBox(height: 10,);
const String logo= 'https://tse4.mm.bing.net/th?id=OIP.tq89g0ckjJq_vVFWEVi8fwHaHa&pid=Api&P=0';