import 'package:flutter/material.dart';

List<Color> tileColors = <Color>[Colors.black,Colors.blue.shade300,Colors.blue.shade500];